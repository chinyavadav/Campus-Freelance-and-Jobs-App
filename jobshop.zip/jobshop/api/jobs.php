<?php
include("connection.php");
$availablejobs=array();
$date=date('Y-m-d H:i:s');
$statement="SELECT * FROM tbljobs JOIN tblcompanies ON tbljobs.flduser_id=tblcompanies.flduser_id WHERE tbljobs.fldstatus='Open' and tbljobs.flddue_timestamp>'$date' ORDER BY tbljobs.fldjob_id DESC";
$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
while($record=mysqli_fetch_assoc($query)){          
    $availablejobs[]=$record;
}
echo json_encode($availablejobs);   
?>