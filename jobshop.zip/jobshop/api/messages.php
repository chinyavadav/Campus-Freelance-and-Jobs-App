<?php
	include("connection.php");
    if(isset($_GET["userid"])){
        $messages=array();
        $array=array();
        $userid=mysqli_real_escape_string($conn,$_GET["userid"]);
        $statement="SELECT * FROM tblmessages WHERE fldfrom='$userid' or fldto='$userid'";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        
        while($record=mysqli_fetch_assoc($query)){
            $temp=array();
            $temp["messageId"]=$record["fldmessage_id"];
            $temp["fromUserId"]=$record["fldfrom"];
            $temp["toUserId"]=$record["fldto"];            
            $temp["time"]=$record["fldtimestamp"];
            $temp["message"]=$record["fldmessage"];
            $temp["type"]=$record["fldtype"];
            $temp["status"]="success";

            $statement="SELECT * FROM tblusers WHERE flduser_id='$record[fldto]' or flduser_id='$record[fldfrom]'";
            $client_query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
            while($client=mysqli_fetch_assoc($client_query)){
                if($client["flduser_id"]==$record["fldfrom"]){
                    $temp["fromUserName"]=$client['fldforename'].' '.$client['fldsurname'];
                }elseif($client["flduser_id"]==$record["fldto"]){
                    $temp["toUserName"]=$client['fldforename'].' '.$client['fldsurname'];
                }
            }
            $array[]=$temp;
        }
        $messages["array"]=$array;
        echo json_encode($messages);
    }
?>