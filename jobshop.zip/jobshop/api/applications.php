<?php
include("connection.php");
$applicantions=array();
if(isset($_GET['user_id'])){
	$user_id=mysqli_real_escape_string($conn,$_GET["user_id"]);
	$statement="SELECT * FROM tblapplications JOIN tbljobs ON tblapplications.fldjob_id=tbljobs.fldjob_id WHERE tblapplications.flduser_id='$user_id'";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	while($record=mysqli_fetch_assoc($query)){          
		$applicantions[]=$record;
	}
}
echo json_encode($applicantions);   
?>