<?php
	include("connection.php");
	if(isset($_GET["from"]) && isset($_GET["to"]) && isset($_GET["message"])){
        $from=mysqli_real_escape_string($conn,$_GET["from"]);
        $to=mysqli_real_escape_string($conn,$_GET["to"]);	        
        $message=mysqli_real_escape_string($conn,$_GET["message"]);
        $type=mysqli_real_escape_string($conn,$_GET["type"]);
        $timestamp=date('Y-m-d H:i:s');
        $statement="INSERT INTO tblmessages(fldfrom,fldto,fldmessage,fldtype,fldtimestamp) VALUES('$from','$to','$message','$type','$timestamp')";
	    $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	    $response=array("response"=>"success");
	    echo json_encode($response);
	}
		    
?>