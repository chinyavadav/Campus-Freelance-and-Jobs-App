<?php
include("connection.php");
if(isset($_GET["skill"]) && isset($_GET["user_id"])){        
	$skill = mysqli_real_escape_string($conn,$_GET["skill"]);
	$user_id = mysqli_real_escape_string($conn,$_GET["user_id"]);
	$statement="DELETE FROM tblskills WHERE fldskill='$skill' and flduser_id='$user_id'";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	$response['response']='success';
} else{
	$response=array("response"=>"failed");
}
echo json_encode($response);

?>