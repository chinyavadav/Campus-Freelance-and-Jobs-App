<?php
	include("connection.php");
	header('Content-Type: application/json');
	if($_SERVER["REQUEST_METHOD"]=="POST"){		
	    $postdata = file_get_contents("php://input");
	    if (isset($postdata)) {
	        $request = json_decode($postdata);
	        $user_id=mysqli_real_escape_string($conn,$request->user_id);
	        $title=mysqli_real_escape_string($conn,$request->title);
	        $job_type=mysqli_real_escape_string($conn,$request->job_type);
	        $job_status=mysqli_real_escape_string($conn,$request->job_status);
	        $created_timestamp=date('Y-m-d H:i:s');
	        $due_timestamp=mysqli_real_escape_string($conn,$request->due_timestamp);
	        $description=mysqli_real_escape_string($conn,$request->description);
	        $offer=mysqli_real_escape_string($conn,$request->offer);
	        $picture=$request->picture;

	        $statement="INSERT INTO tbljobs(flduser_id,fldtitle,fldtype,fldcreated_timestamp,flddue_timestamp,	fldjob_description,fldoffer,fldstatus,fldpicture) VALUES('$user_id','$title','$job_type','$created_timestamp','$due_timestamp','$description','$offer','$job_status','$picture')";
	        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	        $response=array("response"=>"success");
		}else {
	        $response=array("response"=>"failed");
	    }
	    echo json_encode($response);	    
	}

	function failed(){
		$response=array("response"=>"failed");
		echo json_encode($response);
	}
?>