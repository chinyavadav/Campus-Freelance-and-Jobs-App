<?php
include("connection.php");
$skills=array();
if(isset($_GET["user_id"])){
	$user_id=mysqli_real_escape_string($conn,$_GET["user_id"]);
	$statement="SELECT * FROM tblskills WHERE flduser_id='$user_id'";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	while($record=mysqli_fetch_assoc($query)){          
		$skills[]=$record;
	}
}
echo json_encode($skills);   
?>