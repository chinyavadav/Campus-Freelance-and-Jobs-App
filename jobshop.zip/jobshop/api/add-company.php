<?php
	include("connection.php");
	header('Content-Type: application/json');
	if($_SERVER["REQUEST_METHOD"]=="POST"){		
	    $postdata = file_get_contents("php://input");
	    if (isset($postdata)) {
	        $request = json_decode($postdata);
	        $user_id=mysqli_real_escape_string($conn,$request->user_id);
	        $company_name=mysqli_real_escape_string($conn,$request->company_name);
	        $company_type=mysqli_real_escape_string($conn,$request->company_type);
	        $description=mysqli_real_escape_string($conn,$request->description);
	        $email=mysqli_real_escape_string($conn,$request->email);
	        $website=mysqli_real_escape_string($conn,$request->website);
	        $picture=$request->picture;

	        $statement="INSERT INTO tblcompanies VALUES('$user_id','$company_name','$company_type','Unverified','$description','$email','$website','$picture')";
	        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	        $response=array("response"=>"success");
		}else {
	        $response=array("response"=>"failed");
	    }
	    echo json_encode($response);	    
	}

	function failed(){
		$response=array("response"=>"failed");
		echo json_encode($response);
	}
?>