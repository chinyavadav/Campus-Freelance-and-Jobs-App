<?php
include("connection.php");
header('Content-Type: application/json');
if($_SERVER["REQUEST_METHOD"]=="POST"){		
	$postdata = file_get_contents("php://input");
	if (isset($postdata)) {
		$request = json_decode($postdata);
		$job_id=mysqli_real_escape_string($conn,$request->job_id);
		$user_id=mysqli_real_escape_string($conn,$request->user_id);
		$why=mysqli_real_escape_string($conn,$request->why);
		$bid=mysqli_real_escape_string($conn,$request->bid);
		$timestamp=date('Y-m-d H:i:s');

		$statement="INSERT INTO tblapplications(fldjob_id, flduser_id, fldwhy, fldbid, fldtimestamp) VALUES('$job_id','$user_id','$why','$bid','$timestamp')";

		$stmt="UPDATE tblapplications SET fldjob_id='$job_id', flduser_id='$user_id', fldwhy='$why', fldbid='$bid', fldtimestamp='$timestamp'";

		$query=mysqli_query($conn,$statement) or die(update($conn,$stmt));
		$response=array("response"=>"success");
	}else {
		$response=array("response"=>"failed");
	}
	echo json_encode($response);	    
}

function update($conn,$stmt){
	$query=mysqli_query($conn,$statement) or die(failed());
	$response=array("response"=>"success");
	echo json_encode($response);
}

function failed(){
	$response=array("response"=>"failed");
	echo json_encode($response);
}
?>