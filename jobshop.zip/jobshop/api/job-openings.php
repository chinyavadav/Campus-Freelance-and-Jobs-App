<?php
include("connection.php");
$jobs=array();
if(isset($_GET['user_id'])){
	$user_id=mysqli_real_escape_string($conn,$_GET["user_id"]);
	$date=date('Y-m-d H:i:s');
	$statement="SELECT * FROM tbljobs WHERE flduser_id='$user_id' ORDER BY fldjob_id DESC";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	while($record=mysqli_fetch_assoc($query)){          
		$jobs[]=$record;
	}
}
echo json_encode($jobs);   
?>