<?php
	include("connection.php");
    if(isset($_GET["userid"])){
        $chats=array();
        $userid=mysqli_real_escape_string($conn,$_GET["userid"]);
        $statement="SELECT DISTINCT fldfrom,fldto FROM tblmessages WHERE fldfrom='$userid' or fldto='$userid'";
        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
        
        while($record=mysqli_fetch_assoc($query)){
            $temp=array();
            if($userid==$record["fldto"]){
                $temp["userid"]=$record["fldfrom"];
            }else{
                $temp["userid"]=$record["fldto"];
            }
            $statement="SELECT * FROM tblusers WHERE flduser_id='$record[fldto]' or flduser_id='$record[fldfrom]'";
            $user_query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
            while($user=mysqli_fetch_assoc($user_query)){
                if($user["flduser_id"]==$temp["userid"]){
                    $temp['userid']="$user[flduser_id]";
                    $temp['phoneno']="$user[fldphone_no]";
                    $temp["fullname"]="$user[fldforename] $user[fldsurname]";
                }
            }
            $chats[]=$temp;
        }
        $chats=(array)array_unique($chats, SORT_REGULAR);
        $chats=array_values($chats);
        echo json_encode($chats);
    }
?>