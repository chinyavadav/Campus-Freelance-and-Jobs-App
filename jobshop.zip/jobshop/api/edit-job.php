<?php
	include("connection.php");
	header('Content-Type: application/json');
	if($_SERVER["REQUEST_METHOD"]=="POST"){		
	    $postdata = file_get_contents("php://input");
	    if (isset($postdata) && isset($_GET["job_id"])) {

	        $request = json_decode($postdata);
	        $user_id=mysqli_real_escape_string($conn,$request->user_id);
	        $job_id=mysqli_real_escape_string($conn,$_GET['job_id']);
	        $title=mysqli_real_escape_string($conn,$request->title);
	        $job_type=mysqli_real_escape_string($conn,$request->job_type);
	        $job_status=mysqli_real_escape_string($conn,$request->job_status);
	        $created_timestamp=date('Y-m-d H:i:s');
	        $due_timestamp=mysqli_real_escape_string($conn,$request->due_timestamp);
	        $description=mysqli_real_escape_string($conn,$request->description);
	        $offer=mysqli_real_escape_string($conn,$request->offer);
	        $picture=$request->picture;

	        $statement="UPDATE tbljobs SET flduser_id='$user_id', fldtitle='$title', fldtype='$job_type', fldcreated_timestamp='$created_timestamp', flddue_timestamp='$due_timestamp', fldjob_description='$description', fldoffer='$offer', fldstatus='$job_status', fldpicture='$picture' WHERE fldjob_id='$job_id'";
	        $query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	        $response=array("response"=>"success");
		}else {
	        $response=array("response"=>"failed");
	    }
	    echo json_encode($response);	    
	}

	function failed(){
		$response=array("response"=>"failed");
		echo json_encode($response);
	}
?>