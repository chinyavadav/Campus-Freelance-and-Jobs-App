<?php
include("connection.php");
header('Content-Type: application/json');
if(isset($_GET["status"]) && isset($_GET["job_id"])){
	$status=mysqli_real_escape_string($conn,$_GET["status"]);
	$job_id=mysqli_real_escape_string($conn,$_GET["job_id"]);

	$statement="UPDATE tbljobs SET fldstatus='$status' WHERE fldjob_id='$job_id'";
	$query=mysqli_query($conn,$statement) or die(mysqli_error($conn));
	$response=array("response"=>"success");
	echo json_encode($response);	    
}

function failed(){
	$response=array("response"=>"failed");
	echo json_encode($response);
}
?>